//
//  iExpenseApp.swift
//  iExpense
//
//  Created by Zheen Suseyi on 12/25/24.
//

import SwiftUI

@main
struct iExpenseApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
